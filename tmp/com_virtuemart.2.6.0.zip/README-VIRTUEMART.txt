Installation procedure is described here:
http://docs.virtuemart.net/tutorials/30-installation-migration-upgrade-vm-2/80-installation-of-virtuemart-2

Install first the core, then the aio!