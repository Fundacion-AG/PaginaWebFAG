<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
/**
 * HTML View class for the ALFContact Component
 */
class AlfcontactViewResponse extends JViewLegacy
{
    
}
