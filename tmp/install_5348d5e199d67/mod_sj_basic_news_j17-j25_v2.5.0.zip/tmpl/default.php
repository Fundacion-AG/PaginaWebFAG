<?php
/**
 * @package Sj Basic News
 * @version 2.5
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @copyright (c) 2012 YouTech Company. All Rights Reserved.
 * @author YouTech Company http://www.smartaddons.com
 * 
 */
defined('_JEXEC') or die;?>

<?php 
	$options=$params->toObject();
	$image_config = array(
    	'output_width'  => $params->get('item_image_width'),
    	'output_height' => $params->get('item_image_height'),
    	'function'		=> $params->get('item_image_function'),
    	'background'	=> $params->get('item_image_background')
    );
?>
<?php
	if (!empty($list)) { ?>
	<?php if ( !empty($options->pretext)){ ?>
         <div class="basicnews_footertext"><?php echo $options->pretext; ?></div>
    <?php } ?>
<div class="widget-wrap">
 <?php $count = 0; foreach ($list as $item) { 
 $count++; 
 if($count == count($list)){
	 $iditem = ' last-item';
 }else if($count == 1){
	 $iditem = ' first-item';
 }else{
	 $iditem = '';
 }
 ?>
  <div class="<?php echo $module->id; ?> post <?php if($params->get('showline')){ echo 'showlinebottom'.$iditem; } ?>">
        <div class="post-inner">
	        <?php if ($options->item_image_display==1 ){?>
	        	<a class="alignleft" title="<?php echo $item['title']?>" target="<?php echo $options->item_link_target; ?>" href="<?php echo $item['link']?>">
	        		<img src="<?php echo Ytools::resize($item['image'], $image_config);?>" title="<?php echo YTools::truncate($item['title'], $options->item_title_max_characs)?>" alt="<?php echo $item['link'];?>"   style="width: <?php echo $options->item_image_width?>px; height:<?php echo $options->item_image_height?>px;" />
	        	</a>
	        <?php } ?>
		        <h2>
		        	<a title="<?php echo $item['title']?>" target="<?php echo $options->item_link_target; ?>" href="<?php echo $item['link']?>"><?php echo YTools::truncate($item['title'],$options->item_title_max_characs);?></a>
		        </h2>
		   <?php if ($options->item_desc_display == 1 ){?>
	            <p class="basicnews-desc"><?php echo Ytools::truncate($item['desc'],$options->item_desc_max_characs);?></p>
	       <?php } ?>
		   <?php if( $options->item_date_display==1 ){?>
	        <p>
		       <?php if($options->cat_title_display==1) {?>
		            <span class="cattitle"><?php echo $item['cattitle']; ?> </span>
		       <?php } ?>
		       <?php if ($options->item_date_display == 1):?>
		       		<span class="basic-date"><?php echo $item['created']?></span>
		        <?php endif; ?>
	        </p>       	
	        <?php } ?>
        </div>
  </div>  
  <?php } ?>
</div>
	<?php if ( !empty($options->posttext)){ ?>
         <div class="basicnews_footertext"><?php echo $options->posttext; ?></div>
    <?php } ?>
<?php } else { ?>
<p>Has no connect to show!</p>
<?php } ?>


